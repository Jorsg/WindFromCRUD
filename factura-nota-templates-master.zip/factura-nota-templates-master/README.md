# Templates Factura y Nota de pedidos


# Nota de pedidos

![](image/screennota.png)




# Factura

![](image/screenfactura.png)
